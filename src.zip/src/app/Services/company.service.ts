import { Injectable, OnInit } from '@angular/core';
import { SessionStorageService } from 'angular-web-storage';

@Injectable({
  providedIn: 'root'
})
export class CompanyService implements OnInit {

  constructor(public sessionStorage: SessionStorageService) {
    let defaultCompany: any = [{ ID: 1, CompanyName: 'SSG', CompanyRegNo: 'SSG001', EmployeeCount: 500, Address: 'Solinganalur', CMMLevel: 'CMM Level 1', Branch: 'CHN' }];
    if (!this.sessionStorage.get('Companys'))
      this.sessionStorage.set('Companys', defaultCompany);
  }
  ngOnInit() {

  }
  addCompany(vArg) {
    let _Companys: any = this.sessionStorage.get('Companys');
    if (_Companys.filter(data => data.CompanyName == vArg.CompanyName)[0]) {
      return false;
    }
    else {
      _Companys.push({ ID: _Companys.length + 1, CompanyName: vArg.CompanyName, CompanyRegNo: vArg.CompanyRegNo, EmployeeCount: vArg.EmployeeCount, Address: vArg.Address, CMMLevel: vArg.CMMLevel, Branch: vArg.Branch })
      this.sessionStorage.set('Companys', _Companys);
      return true;
    }
  }
  getCompany() {
    return this.sessionStorage.get('Companys');
  }

  editData(id) {
    let companyDetail = this.sessionStorage.get('Companys').filter(data => data.ID == id);
    return companyDetail ? companyDetail[0] : null;
  }
  updateData(id,vArg) {
    console.log(id,vArg);
    console.log(this.sessionStorage.get('Companys'));
    console.log(this.sessionStorage.get('Companys').findIndex(data => data.ID == id));
    let companyIndex: any = this.sessionStorage.get('Companys').findIndex(data => data.ID == id);
    console.log(companyIndex);
    if (companyIndex>-1) {
      let _Companys: any = this.sessionStorage.get('Companys');
      _Companys[companyIndex]={ ID: Number(id), CompanyName: vArg.CompanyName, CompanyRegNo: vArg.CompanyRegNo, EmployeeCount: vArg.EmployeeCount, Address: vArg.Address, CMMLevel: vArg.CMMLevel, Branch: vArg.Branch };
      this.sessionStorage.set('Companys', _Companys);
      return true;
    }
  }
  removeCompany(id){
    let companyIndex: any = this.sessionStorage.get('Companys').findIndex(data => data.ID == id);
    if (companyIndex>-1) {
      let _Companys: any = this.sessionStorage.get('Companys').splice(companyIndex,1);
      this.sessionStorage.set('Companys', _Companys);
      return true;
    }
  }
}
