import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ManageCompanyComponent } from './manage-company/manage-company.component';
import { EditComponent } from './manage-company/edit/edit.component';
import { CreateComponent } from './manage-company/create/create.component';
import { Routes, RouterModule } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';

const routes:Routes=[
  {
    path:'create',
    component:CreateComponent
  },
  {
    path:'edit/:id',
    component:EditComponent
  },
  {
    path:'ManageCompany',
    component:ManageCompanyComponent
  },
  {
    path:'',
    component:ManageCompanyComponent
  }
]


@NgModule({
  declarations: [
    AppComponent,
    ManageCompanyComponent
     ,CreateComponent,
     EditComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes),
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
