import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CompanyService } from '../../Services/company.service';
import { areAllEquivalent } from '@angular/compiler/src/output/output_ast';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {

  title = 'Add Company';
  angForm: FormGroup;
  data: any = {};
  constructor(private companyService: CompanyService, private fb: FormBuilder, private router: Router) {
    this.createForm();
  }
  submitted = false;
  Branchs: any = [{ Code: null, Name: "--Select--" }, { Code: "CHN", Name: "Chennai" }, { Code: "PDY", Name: "Pondicherry" }, { Code: "UAE", Name: "United States" }]

  createForm() {
    this.angForm = this.fb.group({
      CompanyName: ['', Validators.required],
      CompanyRegNo: ['', Validators.required],
      Branch: [null, Validators.required],
      CMMLevel: ['', Validators.required],
      EmployeeCount: ['', Validators.required],
      Address: ['', Validators.required]
    });

  }
  addCompany() {
    this.submitted = true;
    if (this.angForm.invalid) {
      return;
    }
    if (this.companyService.addCompany(this.angForm.value)) {
      alert('Company Created Successfully');
      this.router.navigate(['ManageCompany']);
    }
    else {
      alert("Company Name Already Exist")
    }

  }
  cancelData() {
    if (confirm("Are you sure to cancel this operation?")) {
      this.router.navigate(['ManageCompany']);
    }
  }

  ngOnInit() {
    //this.getDataItem();
  }

}
