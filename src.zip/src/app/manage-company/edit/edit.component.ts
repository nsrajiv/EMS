import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CompanyService } from '../../Services/company.service';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  data: any = {};
  angForm: FormGroup;
  submitted = false;
  ID=0;
  constructor(private route: ActivatedRoute,
    private router: Router,
    private service: CompanyService,
    private fb: FormBuilder) {
    this.createForm();
  }
  Branchs: any = [{ Code: null, Name: "--Select--" }, { Code: "CHN", Name: "Chennai" }, { Code: "PDY", Name: "Pondicherry" }, { Code: "UAE", Name: "United States" }]
  createForm() {
    this.route.params.subscribe(params => {
      this.ID=params['id'];
      this.data = this.service.editData(params['id']);
      this.angForm = this.fb.group({
        CompanyName: [this.data ? this.data.CompanyName : '', Validators.required],
        CompanyRegNo: [this.data ? this.data.CompanyRegNo : '', Validators.required],
        Branch: [this.data ? this.data.Branch : null, Validators.required],
        CMMLevel: [this.data ? this.data.CMMLevel : '', Validators.required],
        EmployeeCount: [this.data ? this.data.EmployeeCount : '', Validators.required],
        Address: [this.data ? this.data.Address : '', Validators.required]
      });
    });

  }

  ngOnInit() {

  }

  updateData() {
    this.submitted = true;
    console.log(this.angForm.value);
    if (this.angForm.invalid) {
      return;
    }
    if (this.service.updateData(this.ID,this.angForm.value)) {
      alert('Company updated Successfully');
      this.router.navigate(['ManageCompany']);
    }
  }
  cancelData() {
    this.router.navigate(['ManageCompany']);
  }
}
