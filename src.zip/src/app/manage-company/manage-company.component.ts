import { Component, OnInit } from '@angular/core';
import { CompanyService } from '../Services/company.service';

@Component({
  selector: 'app-manage-company',
  templateUrl: './manage-company.component.html',
  styleUrls: ['./manage-company.component.css']
})
export class ManageCompanyComponent implements OnInit {

  constructor(private companyService:CompanyService) { }
  Companys:any;
  ngOnInit() {
    this.getCompany();
  }
  getCompany(){
    this.Companys= this.companyService.getCompany();
  }
  removeCompany(id){
    if (confirm("Are you sure to remove this Company?")) {
      this.companyService.removeCompany(id);
      this.getCompany();
    }
  }
}
